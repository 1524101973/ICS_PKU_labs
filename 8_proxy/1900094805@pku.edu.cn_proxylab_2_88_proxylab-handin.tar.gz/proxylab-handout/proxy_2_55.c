//裴虎镇 1900094805
/*
part 1 : 
参考了书上的tiny部分
主要修改为doit部分
proxy主要功能是 收到并分析客户的请求，建立与服务器的连接，把请求发给服务器，再把服务器的相应传回给客户
后面3部分为主要修改内容
part 2 ：
参考了书上的sbuf.c部分和echo.c部分
添加了并发部分
part 3 ：
参考了书上的echo.c部分和读者-写者部分
添加了
*/
#include <stdio.h>
#include "csapp.h"
//#include "sbuf.h"

// Your proxy’s cache should employ an eviction policy that approximates a least-recently-used (LRU) eviction
    // policy. It doesn’t have to be strictly LRU, but it should be something reasonably close.

//MAX_CACHE_SIZE = 1 MiB
//MAX_OBJECT_SIZE = 100 KiB
//MAX_CACHE_SIZE + T * MAX_OBJECT_SIZE
//T is the maximum number of active connections.
/* Recommended max cache and object sizes */
#define MAX_CACHE_SIZE 1049000
#define MAX_OBJECT_SIZE 102400
#define N_THREAD 4
#define SBUF_SIZE 16

typedef struct {
    int *buf;          /* Buffer array */         
    int n;             /* Maximum number of slots */
    int front;         /* buf[(front+1)%n] is first item */
    int rear;          /* buf[rear%n] is last item */
    sem_t mutex;       /* Protects accesses to buf */
    sem_t slots;       /* Counts available slots */
    sem_t items;       /* Counts available items */
} sbuf_t;
/* $end sbuft */

/* You won't lose style points for including this long line in your code */
static const char *user_agent_hdr = "User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:10.0.3) Gecko/20120305 Firefox/10.0.3\r\n";
sbuf_t sbuf;

void doit(int fd);
//void read_requesthdrs(rio_t *rp, char *req_header_buf, char* host);
void read_requesthdrs(rio_t *rp, char *other_hdr);
//int parse_uri(char *uri, char* host, char* port, char *filename, char *cgiargs);
int parse_uri(char *uri, char* host, char* port, char *filename);
void serve_static(int fd, char *filename, int filesize);
void get_filetype(char *filename, char *filetype);
void serve_dynamic(int fd, char *filename, char *cgiargs, char *headers);
void clienterror(int fd, char *cause, char *errnum, 
		 char *shortmsg, char *longmsg);
void changeVersion(char* version);
void parse_line(char* buf, char* method, char* uri, char* version, char* host, char* port, char* filename);

void sbuf_init(sbuf_t *sp, int n);
void sbuf_deinit(sbuf_t *sp);
void sbuf_insert(sbuf_t *sp, int item);
int sbuf_remove(sbuf_t *sp);

/* Create an empty, bounded, shared FIFO buffer with n slots */
void sbuf_init(sbuf_t *sp, int n)
{
    sp->buf = Calloc(n, sizeof(int)); 
    sp->n = n;                       /* Buffer holds max of n items */
    sp->front = sp->rear = 0;        /* Empty buffer iff front == rear */
    Sem_init(&sp->mutex, 0, 1);      /* Binary semaphore for locking */
    Sem_init(&sp->slots, 0, n);      /* Initially, buf has n empty slots */
    Sem_init(&sp->items, 0, 0);      /* Initially, buf has zero data items */
}


/* Clean up buffer sp */
void sbuf_deinit(sbuf_t *sp)
{
    Free(sp->buf);
}

/* Insert item onto the rear of shared buffer sp */
void sbuf_insert(sbuf_t *sp, int item)
{
    P(&sp->slots);                          /* Wait for available slot */
    P(&sp->mutex);                          /* Lock the buffer */
    sp->buf[(++sp->rear)%(sp->n)] = item;   /* Insert the item */
    V(&sp->mutex);                          /* Unlock the buffer */
    V(&sp->items);                          /* Announce available item */
}

/* Remove and return the first item from buffer sp */
int sbuf_remove(sbuf_t *sp)
{
    int item;
    P(&sp->items);                          /* Wait for available item */
    P(&sp->mutex);                          /* Lock the buffer */
    item = sp->buf[(++sp->front)%(sp->n)];  /* Remove the item */
    V(&sp->mutex);                          /* Unlock the buffer */
    V(&sp->slots);                          /* Announce available slot */
    return item;
}


/*
 * doit - handle one HTTP request/response transaction
 */
/* $begin doit */
void doit(int fd) 
{
    int is_static;
    struct stat sbuf;
    char buf[MAXLINE], method[MAXLINE], uri[MAXLINE], version[MAXLINE];
    char host[MAXLINE], port[MAXLINE];
    char filename[MAXLINE], cgiargs[MAXLINE];
    char req_header_buf[MAXLINE];
    char other_header[MAXLINE];
    rio_t rio, server_rio;
    int server_fd;
    /* Read request line and headers */
    Rio_readinitb(&rio, fd);
    if (!Rio_readlineb(&rio, buf, MAXLINE)){
        printf("Error : Empty Request!\n");
        return;
    }
    //分析请求行
    sscanf(buf, "%s %s %s", method, uri, version);
    if (strcasecmp(method, "GET")) {
        clienterror(fd, method, "501", "Not Implemented",
                    "Tiny does not implement this method");
        return;
    }
    if(strncasecmp(version, "HTTP/", 5))
        // clienterror(fd, "502", "Not Implemented",
        //            "Tiny does not implement this method");
        return;
    //int parse_uri(uri, host, port, filename, cgiargs);
    
    is_static = parse_uri(uri, host, port, filename);
    changeVersion(version);
    
    // 生成服务器的请求行和请求报头
    sprintf(req_header_buf, "%s %s %s\r\n", method, filename, version);
    read_requesthdrs(&rio, other_header);
    
    
    //debug
    printf("req_header_buf: ");
    printf("%s\n", req_header_buf);

    //连接服务器
    if((server_fd = open_clientfd(host, port)) < 0 ){
        printf("Server Connection Error!\n");
        return;
    }
    //向服务器发送请求行与请求报头
    Rio_writen(server_fd, req_header_buf, sizeof(req_header_buf));
    char host_hdr[MAXLINE];
    /* 向服务器发送HTTP请求 */
    sprintf(host_hdr, "Host: %s\r\n", host);
    Rio_writen(server_fd, host_hdr, strlen(host_hdr));                          // 以下为请求报头
    Rio_writen(server_fd, user_agent_hdr, strlen(user_agent_hdr));
    Rio_writen(server_fd, "Connection: close\r\n", strlen("Connection: close\r\n"));
    Rio_writen(server_fd, "Proxy-Connection: close\r\n", strlen("Proxy-Connection: close\r\n"));  
    Rio_writen(server_fd, other_header, strlen(other_header));
    Rio_writen(server_fd, "\r\n", strlen("\r\n"));                            // 结尾
    

    // 将服务器响应的内容发送给客户端
    Rio_readinitb(&server_rio, server_fd);
    int n;
    size_t size = 0;
    char content[MAX_OBJECT_SIZE];
    while((n = Rio_readlineb(&server_rio, buf, MAXLINE)) > 0) {
        Rio_writen(fd, buf, n);
        size += n;
        if (size <= MAX_OBJECT_SIZE) {
            strcat(content, buf);
        }
        else break;
    }
    Close(server_fd);
    
    // /* Parse URI from GET request */
    // is_static = parse_uri(uri, filename, cgiargs);
    // if (stat(filename, &sbuf) < 0) {
    //     clienterror(fd, filename, "404", "Not found",
    //             "Tiny couldn't find this file");
    //     return;
    // }

    // if (is_static) { /* Serve static content */          
    //     if (!(S_ISREG(sbuf.st_mode)) || !(S_IRUSR & sbuf.st_mode)) {
    //         clienterror(fd, filename, "403", "Forbidden",
    //             "Tiny couldn't read the file");
    //         return;
    //     }
    //     serve_static(fd, filename, sbuf.st_size);
    // }
    // else { /* Serve dynamic content */
    //     if (!(S_ISREG(sbuf.st_mode)) || !(S_IXUSR & sbuf.st_mode)) {
    //         clienterror(fd, filename, "403", "Forbidden",
    //             "Tiny couldn't run the CGI program");
    //         return;
    //     }
    //     serve_dynamic(fd, filename, cgiargs, req_header_buf);
    // }
}
/* $end doit */

/*
 * parse_uri - parse URI into filename and CGI args
 *             return 0 if dynamic content, 1 if static
 */
/* $begin parse_uri */
int parse_uri(char *uri, char* host, char* port, char *filename) 
{
    
    char *ptr;
    char *tmp1, *tmps, *tmpc;
    //uri : http://www.cmu.edu:8080/hub/index.html
    //host: www.cmu.edu
    //port: 8080
    //filename: /hub/index.html
    if((tmp1 = strstr(uri, "http://")) != NULL){
        ptr = tmp1 + strlen("http://");
    }
    else if((tmp1 = strstr(uri, "https://")) != NULL){
        ptr = tmp1 + strlen("https://");
    }
    else ptr = uri;
    tmps = strstr(ptr, "/");
    tmpc = strstr(ptr, ":");
    if(tmpc == NULL){
        if(tmps == NULL){
            strcpy(host, ptr);
            strcpy(port, "80");
            strcpy(filename, "/home.html");        
        }
        else{
            strncpy(host, ptr, tmps - ptr);
            strcpy(port, "80");
            strcpy(filename, tmps);
        }
    }
    else{
        if(tmps == NULL){
            strncpy(host, ptr, tmpc - ptr);
            strcpy(port, tmpc + 1);
            strcpy(filename, "/home.html");        
        }
        else{
            strncpy(host, ptr, tmpc - ptr);
            strncpy(port, tmpc + 1, tmps - tmpc - 1);
            strcpy(filename, tmps);        
        }
    }
    return 1;
    
    // if (!strstr(uri, "cgi-bin")) {  /* Static content */
    //     strcpy(cgiargs, "");
    //     strcpy(filename, ".");
    //     strcat(filename, uri);
    //     if (uri[strlen(uri)-1] == '/')
    //         strcat(filename, "home.html");
    //     return 1;
    // }
    // else {  /* Dynamic content */
    //     ptr = index(uri, '?');
    //     if (ptr) {
    //         strcpy(cgiargs, ptr+1);
    //         *ptr = '\0';
    //     }
    //     else 
    //         strcpy(cgiargs, "");
    //     strcpy(filename, ".");
    //     strcat(filename, uri);
    //     return 0;
    // }
}
/* $end parse_uri */

void changeVersion(char* version){
    char* tmp_version = NULL;
    if( (tmp_version = strstr(version, "HTTP/1.1")) != NULL){
        version[tmp_version - version + strlen("HTTP/1.1") - 1] = '0';
    }
}

void read_requesthdrs(rio_t *rp, char *other_hdr) {
    char buf[MAXLINE];

    while(Rio_readlineb(rp, buf, MAXLINE) > 0) {
        if (!strcmp(buf, "\r\n"))
            break;
        
        if (strncasecmp(buf, "Connection", 10) != 0 
            && strncasecmp(buf, "Host", 4) != 0
            && strncasecmp(buf, "Proxy-Connection", 16) != 0
            && strncasecmp(buf, "User-Agent", 10)) {
            strcat(other_hdr, buf);
        }
    }
}

void clienterror(int fd, char *cause, char *errnum, 
		 char *shortmsg, char *longmsg) 
{
    char buf[MAXLINE], body[MAXBUF];

    /* Build the HTTP response body */
    sprintf(body, "<html><title>Tiny Error</title>");
    sprintf(body, "%s<body bgcolor=""ffffff"">\r\n", body);
    sprintf(body, "%s%s: %s\r\n", body, errnum, shortmsg);
    sprintf(body, "%s<p>%s: %s\r\n", body, longmsg, cause);
    sprintf(body, "%s<hr><em>The Tiny Web server</em>\r\n", body);

    /* Print the HTTP response */
    sprintf(buf, "HTTP/1.0 %s %s\r\n", errnum, shortmsg);
    rio_writen(fd, buf, strlen(buf));
    sprintf(buf, "Content-type: text/html\r\n");
    rio_writen(fd, buf, strlen(buf));
    sprintf(buf, "Content-length: %d\r\n\r\n", (int)strlen(body));
    rio_writen(fd, buf, strlen(buf));
    rio_writen(fd, body, strlen(body));
}

void* thread(void* vargp){
    Pthread_detach(pthread_self());
    while(1){
        int connfd = sbuf_remove(&sbuf);
        doit(connfd);
        Close(connfd);
    }
    return;
}

int main(int argc, char **argv) 
{
    int listenfd, connfd;
    char hostname[MAXLINE], port[MAXLINE];
    socklen_t clientlen;
    struct sockaddr_storage clientaddr;//sockaddr_in

    /* Check command line args */
    if (argc != 2) {
        fprintf(stderr, "usage: %s <port>\n", argv[0]);
        exit(1);
    }

    listenfd = open_listenfd(argv[1]);

    pthread_t tid;
    sbuf_init(&sbuf, SBUF_SIZE);

    for (int i = 0; i < N_THREAD; i++)
    {
        Pthread_create(&tid, NULL, thread, NULL);
    }
    

    while (1) {
        clientlen = sizeof(clientaddr);
        connfd = accept(listenfd, (SA *)&clientaddr, &clientlen);
        getnameinfo((SA *) &clientaddr, clientlen, hostname, MAXLINE, 
                        port, MAXLINE, 0);
        printf("Accepted connection from (%s, %s)\n", hostname, port);
        sbuf_insert(&sbuf, connfd);
    }
}