#include <stdio.h>
#include "csapp.h"
/* Recommended max cache and object sizes */
#define MAX_CACHE_SIZE 1049000
#define MAX_OBJECT_SIZE 102400

/* You won't lose style points for including this long line in your code */
static const char *user_agent_hdr = "User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:10.0.3) Gecko/20120305 Firefox/10.0.3\r\n";

void doit(int fd);
//void read_requesthdrs(rio_t *rp, char *req_header_buf, char* host);
void read_requesthdrs(rio_t *rp, char *other_hdr);
//int parse_uri(char *uri, char* host, char* port, char *filename, char *cgiargs);
int parse_uri(char *uri, char* host, char* port, char *filename);
void serve_static(int fd, char *filename, int filesize);
void get_filetype(char *filename, char *filetype);
void serve_dynamic(int fd, char *filename, char *cgiargs, char *headers);
void clienterror(int fd, char *cause, char *errnum, 
		 char *shortmsg, char *longmsg);
void changeVersion(char* version);
void parse_line(char* buf, char* method, char* uri, char* version, char* host, char* port, char* filename);


/*
 * doit - handle one HTTP request/response transaction
 */
/* $begin doit */
void doit(int fd) 
{
    int is_static;
    struct stat sbuf;
    char buf[MAXLINE], method[MAXLINE], uri[MAXLINE], version[MAXLINE];
    char host[MAXLINE], port[MAXLINE];
    char filename[MAXLINE], cgiargs[MAXLINE];
    char req_header_buf[MAXLINE];
    char other_header[MAXLINE];
    rio_t rio, server_rio;
    int server_fd;
    /* Read request line and headers */
    Rio_readinitb(&rio, fd);
    if (!Rio_readlineb(&rio, buf, MAXLINE)){
        printf("Error : Empty Request!\n");
        return;
    }
    //分析请求行
    sscanf(buf, "%s %s %s", method, uri, version);
    if (strcasecmp(method, "GET")) {
        clienterror(fd, method, "501", "Not Implemented",
                    "Tiny does not implement this method");
        return;
    }
    if(strncasecmp(version, "HTTP/", 5))
        // clienterror(fd, "502", "Not Implemented",
        //            "Tiny does not implement this method");
        return;
    //int parse_uri(uri, host, port, filename, cgiargs);
    
    is_static = parse_uri(uri, host, port, filename);
    changeVersion(version);
    
    // 生成服务器的请求行和请求报头
    sprintf(req_header_buf, "%s %s %s\r\n", method, filename, version);
    read_requesthdrs(&rio, other_header);
    
    
    //debug
    printf("req_header_buf done\n");
    printf("%s\n", req_header_buf);

    //连接服务器
    if((server_fd = open_clientfd(host, port)) < 0 ){
        printf("Server Connection Error!\n");
        return;
    }
    //向服务器发送请求行与请求报头
    Rio_writen(server_fd, req_header_buf, sizeof(req_header_buf));
    char host_hdr[MAXLINE];
    /* 向服务器发送HTTP请求 */
    sprintf(host_hdr, "Host: %s\r\n", host);
    Rio_writen(server_fd, host_hdr, strlen(host_hdr));                          // 以下为请求报头
    Rio_writen(server_fd, user_agent_hdr, strlen(user_agent_hdr));
    Rio_writen(server_fd, "Connection: close\r\n", strlen("Connection: close\r\n"));
    Rio_writen(server_fd, "Proxy-Connection: close\r\n", strlen("Proxy-Connection: close\r\n"));  
    Rio_writen(server_fd, other_header, strlen(other_header));
    Rio_writen(server_fd, "\r\n", strlen("\r\n"));                            // 结尾
    

    // 将服务器响应的内容发送给客户端
    Rio_readinitb(&server_rio, server_fd);
    int n;
    size_t size = 0;
    char content[MAX_OBJECT_SIZE];
    while((n = Rio_readlineb(&server_rio, buf, MAXLINE)) > 0) {
        Rio_writen(fd, buf, n);
        size += n;
        if (size <= MAX_OBJECT_SIZE) {
            strcat(content, buf);
        }
        else break;
    }
    Close(server_fd);
    
    // /* Parse URI from GET request */
    // is_static = parse_uri(uri, filename, cgiargs);
    // if (stat(filename, &sbuf) < 0) {
    //     clienterror(fd, filename, "404", "Not found",
    //             "Tiny couldn't find this file");
    //     return;
    // }

    // if (is_static) { /* Serve static content */          
    //     if (!(S_ISREG(sbuf.st_mode)) || !(S_IRUSR & sbuf.st_mode)) {
    //         clienterror(fd, filename, "403", "Forbidden",
    //             "Tiny couldn't read the file");
    //         return;
    //     }
    //     serve_static(fd, filename, sbuf.st_size);
    // }
    // else { /* Serve dynamic content */
    //     if (!(S_ISREG(sbuf.st_mode)) || !(S_IXUSR & sbuf.st_mode)) {
    //         clienterror(fd, filename, "403", "Forbidden",
    //             "Tiny couldn't run the CGI program");
    //         return;
    //     }
    //     serve_dynamic(fd, filename, cgiargs, req_header_buf);
    // }
}
/* $end doit */

/*
 * parse_uri - parse URI into filename and CGI args
 *             return 0 if dynamic content, 1 if static
 */
/* $begin parse_uri */
int parse_uri(char *uri, char* host, char* port, char *filename) 
{
    
    char *ptr;
    char *tmp1, *tmps, *tmpc;
    //uri : http://www.cmu.edu:8080/hub/index.html
    //host: www.cmu.edu
    //port: 8080
    //filename: /hub/index.html
    if((tmp1 = strstr(uri, "http://")) != NULL){
        ptr = tmp1 + strlen("http://");
    }
    else if((tmp1 = strstr(uri, "https://")) != NULL){
        ptr = tmp1 + strlen("https://");
    }
    else ptr = uri;
    tmps = strstr(ptr, "/");
    tmpc = strstr(ptr, ":");
    if(tmpc == NULL){
        if(tmps == NULL){
            strcpy(host, ptr);
            strcpy(port, "80");
            strcpy(filename, "/home.html");        
        }
        else{
            strncpy(host, ptr, tmps - ptr);
            strcpy(port, "80");
            strcpy(filename, tmps);
        }
    }
    else{
        if(tmps == NULL){
            strncpy(host, ptr, tmpc - ptr);
            strcpy(port, tmpc + 1);
            strcpy(filename, "/home.html");        
        }
        else{
            strncpy(host, ptr, tmpc - ptr);
            strncpy(port, tmpc + 1, tmps - tmpc - 1);
            strcpy(filename, tmps);        
        }
    }
    return 1;
    
    // if (!strstr(uri, "cgi-bin")) {  /* Static content */
    //     strcpy(cgiargs, "");
    //     strcpy(filename, ".");
    //     strcat(filename, uri);
    //     if (uri[strlen(uri)-1] == '/')
    //         strcat(filename, "home.html");
    //     return 1;
    // }
    // else {  /* Dynamic content */
    //     ptr = index(uri, '?');
    //     if (ptr) {
    //         strcpy(cgiargs, ptr+1);
    //         *ptr = '\0';
    //     }
    //     else 
    //         strcpy(cgiargs, "");
    //     strcpy(filename, ".");
    //     strcat(filename, uri);
    //     return 0;
    // }
}
/* $end parse_uri */

void changeVersion(char* version){
    char* tmp_version = NULL;
    if( (tmp_version = strstr(version, "HTTP/1.1")) != NULL){
        version[tmp_version - version + strlen("HTTP/1.1") - 1] = '0';
    }
}

/*
 * read_requesthdrs - read HTTP request headers
 */
/* $begin read_requesthdrs */
// void read_requesthdrs(rio_t *rp, char *req_header_buf, char* host) 
// {
//     int UserAgent = 0, Connection = 0,
//         ProxyConnection = 0, HostInfo = 0;
//     char buf[MAXLINE];
//     int n;
    
//     n = rio_readlineb(rp, buf, MAXLINE);
//     printf("receive buf %s\n", buf);
//     printf("n == %d\n", n);
//     char* findp;
//     while(strcmp("\r\n", buf) && n){
//         strcat(req_header_buf, buf);
//         printf("receive buf %s\n", buf);

//         if( (findp = strstr(buf,"user-Agent:")) != NULL)
//          UserAgent = 1;
//         else if( (findp = strstr(buf,"Proxy-Connection:")) != NULL)
//             ProxyConnection = 1;
//         else if( (findp = strstr(buf,"Connection:")) != NULL)
//             Connection = 1;
//         else if( (findp = strstr(buf,"Host:")) != NULL){
//             HostInfo = 1;
//         }
        
//         n = rio_readlineb(rp, buf, MAXLINE);
//     }
//     if(n == 0){
//         return;
//     }

//     if(HostInfo == 0){
//         sprintf(buf, "Host: %s\r\n", host);
//         strcat(req_header_buf,buf);
//     }

//     if(UserAgent == 0){
//         strcat(req_header_buf, user_agent_hdr);
//     }
//     if(Connection == 0){
//         sprintf(buf,"Connection: close\r\n");
//         strcat(req_header_buf, buf);
//     }
//     if(ProxyConnection == 0){
//         sprintf(buf,"Proxy-Connection: close\r\n");
//         strcat(req_header_buf, buf);
//     }
//     strcat(req_header_buf, "\r\n");
//     return;
// }

void read_requesthdrs(rio_t *rp, char *other_hdr) {
    char buf[MAXLINE];

    while(Rio_readlineb(rp, buf, MAXLINE) > 0) {
        if (!strcmp(buf, "\r\n"))
            break;
        
        if (strncasecmp(buf, "Connection", 10) != 0 
            && strncasecmp(buf, "Host", 4) != 0
            && strncasecmp(buf, "Proxy-Connection", 16) != 0
            && strncasecmp(buf, "User-Agent", 10)) {
            strcat(other_hdr, buf);
        }
    }
}

/* $end read_requesthdrs */

void clienterror(int fd, char *cause, char *errnum, 
		 char *shortmsg, char *longmsg) 
{
    char buf[MAXLINE], body[MAXBUF];

    /* Build the HTTP response body */
    sprintf(body, "<html><title>Tiny Error</title>");
    sprintf(body, "%s<body bgcolor=""ffffff"">\r\n", body);
    sprintf(body, "%s%s: %s\r\n", body, errnum, shortmsg);
    sprintf(body, "%s<p>%s: %s\r\n", body, longmsg, cause);
    sprintf(body, "%s<hr><em>The Tiny Web server</em>\r\n", body);

    /* Print the HTTP response */
    sprintf(buf, "HTTP/1.0 %s %s\r\n", errnum, shortmsg);
    rio_writen(fd, buf, strlen(buf));
    sprintf(buf, "Content-type: text/html\r\n");
    rio_writen(fd, buf, strlen(buf));
    sprintf(buf, "Content-length: %d\r\n\r\n", (int)strlen(body));
    rio_writen(fd, buf, strlen(buf));
    rio_writen(fd, body, strlen(body));
}

int main(int argc, char **argv) 
{
    int listenfd, connfd;
    char hostname[MAXLINE], port[MAXLINE];
    socklen_t clientlen;
    struct sockaddr_storage clientaddr;//sockaddr_in

    /* Check command line args */
    if (argc != 2) {
        fprintf(stderr, "usage: %s <port>\n", argv[0]);
        exit(1);
    }

    listenfd = open_listenfd(argv[1]);
    while (1) {
        clientlen = sizeof(clientaddr);
        connfd = accept(listenfd, (SA *)&clientaddr, &clientlen);
            getnameinfo((SA *) &clientaddr, clientlen, hostname, MAXLINE, 
                        port, MAXLINE, 0);
            printf("Accepted connection from (%s, %s)\n", hostname, port);
        doit(connfd);
        close(connfd);
    }
}