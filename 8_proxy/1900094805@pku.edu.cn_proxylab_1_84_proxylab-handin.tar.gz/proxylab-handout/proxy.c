//裴虎镇 1900094805
/*
part 1 : 
参考了书上的tiny部分
主要修改为doit部分
proxy主要功能是 收到并分析客户的请求，建立与服务器的连接，把请求发给服务器，再把服务器的相应传回给客户
后面3部分为主要修改内容
part 2 ：
参考了书上的sbuf.c部分和echo.c部分
添加了并发部分
part 3 ：
参考了书上的echo.c部分和读者-写者部分
由于发现可以去掉sbuf中的部分，就顺便去掉啦
添加了利用cache的部分
主要是：
cache_search 从cache中寻找
cache_read 从cache中调出相应块
cache_write 向cache写入
update_LRU 根据LRU策略更新数值
*/
#include <stdio.h>
#include "csapp.h"

// Your proxy’s cache should employ an eviction policy that approximates a least-recently-used (LRU) eviction
    // policy. It doesn’t have to be strictly LRU, but it should be something reasonably close.

//MAX_CACHE_SIZE = 1 MiB
//MAX_OBJECT_SIZE = 100 KiB
//MAX_CACHE_SIZE + T * MAX_OBJECT_SIZE
//T is the maximum number of active connections.
/* Recommended max cache and object sizes */
#define MAX_CACHE_SIZE 1049000
#define MAX_OBJECT_SIZE 102400
#define N_THREAD 4
#define MAX_CACHE_NUM 200
#define debug 
typedef struct {
    int LRU;
    char uri[MAXLINE];
    char content[MAX_OBJECT_SIZE];
    int sizeContent;
    sem_t mutex, w;
    int readcnt;    
}myCacheBlock;

typedef struct {
    myCacheBlock block[MAX_CACHE_SIZE];
    int cnt, LRU_cur, sizeTotal;
    sem_t mutex;
}myCache;

/* You won't lose style points for including this long line in your code */
static const char *user_agent_hdr = "User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:10.0.3) Gecko/20120305 Firefox/10.0.3\r\n";

static myCache cache;
void doit(int fd);
//void read_requesthdrs(rio_t *rp, char *req_header_buf, char* host);
void read_requesthdrs(rio_t *rp, char *other_hdr);
//int parse_uri(char *uri, char* host, char* port, char *filename, char *cgiargs);
int parse_uri(char *uri, char* host, char* port, char *filename);
void serve_static(int fd, char *filename, int filesize);
void get_filetype(char *filename, char *filetype);
void serve_dynamic(int fd, char *filename, char *cgiargs, char *headers);
// void clienterror(int fd, char *cause, char *errnum, 
		//  char *shortmsg, char *longmsg);
void changeVersion(char* version);

void block_init(myCacheBlock *b);
void cache_init(myCache *c);
int cache_search(char *uri, myCache *c);
void cache_write(myCache *c, char *uri, char *buf, int size);
void update_LRU(myCache *c, int index);

void block_init(myCacheBlock *b) {
    Sem_init(&b -> mutex, 0, 1);
    Sem_init(&b -> w, 0, 1);
    b -> sizeContent = 0;
    b -> readcnt = 0;
}

void cache_init(myCache *c) {
    int i;
    for (i = 0; i < MAX_CACHE_NUM; ++i) {
        block_init(&c -> block[i]);
    }
    c -> cnt = 0;
    c -> LRU_cur = 0;
    c -> sizeTotal = 0;
    Sem_init(&c -> mutex, 0, 1);
}

int cache_search(char *uri, myCache *c) {
    int i;
    for (i = 0; i < c -> cnt; ++i) {
        if (strcmp(uri, c -> block[i].uri) == 0) {
            return i;
        }
    }
    return -1;
}

void cache_read(myCache *c, int index, int fd) {
    P(&c -> block[index].mutex);
    c -> block[index].readcnt++;
    if (c -> block[index].readcnt == 1)
        P(&c -> block[index].w);
    V(&c -> block[index].mutex);

    Rio_writen(fd, c -> block[index].content, c -> block[index].sizeContent);

    P(&c -> block[index].mutex);
    c -> block[index].readcnt--;
    if (c -> block[index].readcnt == 0)
        V(&c -> block[index].w);
    V(&c -> block[index].mutex);
}

void cache_write(myCache *c, char *uri, char *buf, int size) {
    int index;
    P(&c -> mutex);
    if (c -> cnt < MAX_CACHE_NUM && c -> sizeTotal < MAX_CACHE_SIZE) {
        index = c -> cnt++;
        c -> sizeTotal += size;
    }
    else {
        int i, ans = c -> block[0].LRU;
        index = 0;
        for (i = 1; i < c -> cnt; ++i) {
            if (c -> block[i].LRU < ans) {
                index = i;
                ans = c -> block[i].LRU;
            }
        }  
        c -> sizeTotal += size - c -> block[index].sizeContent;        
    }
    V(&c -> mutex);

    P(&c -> block[index].w);
    strcpy(c -> block[index].uri, uri);
    memcpy(c -> block[index].content, buf, size);
    c -> block[index].sizeContent = size;
    V(&c -> block[index].w);

    update_LRU(c, index);
}

void update_LRU(myCache *c, int index) {
    P(&c -> mutex);
    c -> block[index].LRU = c -> LRU_cur++;
    V(&c -> mutex);
    return;
}




/*
 * doit - handle one HTTP request/response transaction
 */
/* $begin doit */
void doit(int fd) 
{
    //int is_static;
    char buf[MAXLINE], method[MAXLINE], uri[MAXLINE], version[MAXLINE];
    char host[MAXLINE], port[MAXLINE];
    char filename[MAXLINE];
    char req_header_buf[MAXLINE+30];
    char other_header[MAXLINE];
    char uri_cache[MAXLINE];
    rio_t rio, server_rio;
    int server_fd;
    int index_cache;
    /* Read request line and headers */
    Rio_readinitb(&rio, fd);
    if (!Rio_readlineb(&rio, buf, MAXLINE)){
        printf("Error : Empty Request!\n");
        return;
    }
    //分析请求行
    sscanf(buf, "%s %s %s", method, uri, version);
    if (strcasecmp(method, "GET")) {
        // clienterror(fd, method, "501", "Not Implemented",
        //             "Tiny does not implement this method");
        return;
    }
    if(strncasecmp(version, "HTTP/", 5))
        // clienterror(fd, "502", "Not Implemented",
        //            "Tiny does not implement this method");
        return;
    if(strlen(uri) > MAXLINE) 
        return;
    
    //在cache中寻找
#ifdef debug
    printf("Looking for item in cache...\n");
#endif
    strcpy(uri_cache, uri);
    if((index_cache = cache_search(uri_cache, &cache)) != -1){
        cache_read(&cache, index_cache, fd);
        update_LRU(&cache, index_cache);
#ifdef debug
        printf("Success!\n");
#endif
        return;
    }
#ifdef debug
    printf("Failed!\n");
#endif
    //分析uri
    parse_uri(uri, host, port, filename);
    //换版本：1.1->1.0
    changeVersion(version);
#ifdef debug
    printf("Change Version\n");
#endif
    // 生成服务器的请求行和请求报头
    sprintf(req_header_buf, "GET %s HTTP/1.0\r\n", filename);
    read_requesthdrs(&rio, other_header);

#ifdef debug
    printf("req_header_buf: ");
    printf("%s\n", req_header_buf);
#endif
    
    //连接服务器
    if((server_fd = open_clientfd(host, port)) < 0 ){
        printf("Server Connection Error!\n");
        return;
    }
#ifdef debug
    printf("Connected Success!\n");
#endif
    //向服务器发送请求行与请求报头
    Rio_writen(server_fd, req_header_buf, sizeof(req_header_buf));
    char host_hdr[MAXLINE+30];
    /* 向服务器发送HTTP请求 */
    sprintf(host_hdr, "Host: %s\r\n", host);
    Rio_writen(server_fd, host_hdr, strlen(host_hdr));
    Rio_writen(server_fd, (void*)user_agent_hdr, strlen(user_agent_hdr));
    Rio_writen(server_fd, "Connection: close\r\n", strlen("Connection: close\r\n"));
    Rio_writen(server_fd, "Proxy-Connection: close\r\n", strlen("Proxy-Connection: close\r\n"));  
    Rio_writen(server_fd, other_header, strlen(other_header));
    Rio_writen(server_fd, "\r\n", strlen("\r\n"));
    
#ifdef debug
    printf("Send message to server\n");
#endif
    // 将服务器响应的内容发送给客户端
    Rio_readinitb(&server_rio, server_fd);
    int n, size = 0;
    char content[MAX_OBJECT_SIZE];
    while((n = Rio_readlineb(&server_rio, buf, MAXLINE)) > 0) {
        Rio_writen(fd, buf, n);
        size += n;
        if (size <= MAX_OBJECT_SIZE) {
            strcat(content, buf);
        }
    }
    Close(server_fd);
    
    if(size <= MAX_OBJECT_SIZE){
        cache_write(&cache, uri_cache, content, size);
    }
#ifdef debug
    printf("Everything done\n");
#endif
    // /* Parse URI from GET request */
    // is_static = parse_uri(uri, filename, cgiargs);
    // if (stat(filename, &sbuf) < 0) {
    //     clienterror(fd, filename, "404", "Not found",
    //             "Tiny couldn't find this file");
    //     return;
    // }

    // if (is_static) { /* Serve static content */          
    //     if (!(S_ISREG(sbuf.st_mode)) || !(S_IRUSR & sbuf.st_mode)) {
    //         clienterror(fd, filename, "403", "Forbidden",
    //             "Tiny couldn't read the file");
    //         return;
    //     }
    //     serve_static(fd, filename, sbuf.st_size);
    // }
    // else { /* Serve dynamic content */
    //     if (!(S_ISREG(sbuf.st_mode)) || !(S_IXUSR & sbuf.st_mode)) {
    //         clienterror(fd, filename, "403", "Forbidden",
    //             "Tiny couldn't run the CGI program");
    //         return;
    //     }
    //     serve_dynamic(fd, filename, cgiargs, req_header_buf);
    // }
}
/* $end doit */

/*
 * parse_uri - parse URI into filename and CGI args
 *             return 0 if dynamic content, 1 if static
 */
/* $begin parse_uri */
int parse_uri(char *uri, char* host, char* port, char *filename) 
{
    
    char *ptr;
    char *tmp1, *tmps, *tmpc;
    //uri : http://www.cmu.edu:8080/hub/index.html
    //host: www.cmu.edu
    //port: 8080
    //filename: /hub/index.html
    if((tmp1 = strstr(uri, "http://")) != NULL){
        ptr = tmp1 + strlen("http://");
    }
    else if((tmp1 = strstr(uri, "https://")) != NULL){
        ptr = tmp1 + strlen("https://");
    }
    else ptr = uri;
    tmps = strstr(ptr, "/");
    tmpc = strstr(ptr, ":");
    if(tmpc == NULL){
        if(tmps == NULL){
            strcpy(host, ptr);
            strcpy(port, "80");
            strcpy(filename, "/home.html");        
        }
        else{
            strncpy(host, ptr, tmps - ptr);
            strcpy(port, "80");
            strcpy(filename, tmps);
        }
    }
    else{
        if(tmps == NULL){
            strncpy(host, ptr, tmpc - ptr);
            strcpy(port, tmpc + 1);
            strcpy(filename, "/home.html");        
        }
        else{
            strncpy(host, ptr, tmpc - ptr);
            strncpy(port, tmpc + 1, tmps - tmpc - 1);
            strcpy(filename, tmps);        
        }
    }
    return 1;
    
    // if (!strstr(uri, "cgi-bin")) {  /* Static content */
    //     strcpy(cgiargs, "");
    //     strcpy(filename, ".");
    //     strcat(filename, uri);
    //     if (uri[strlen(uri)-1] == '/')
    //         strcat(filename, "home.html");
    //     return 1;
    // }
    // else {  /* Dynamic content */
    //     ptr = index(uri, '?');
    //     if (ptr) {
    //         strcpy(cgiargs, ptr+1);
    //         *ptr = '\0';
    //     }
    //     else 
    //         strcpy(cgiargs, "");
    //     strcpy(filename, ".");
    //     strcat(filename, uri);
    //     return 0;
    // }
}
/* $end parse_uri */

void changeVersion(char* version){
    char* tmp_version = NULL;
    if( (tmp_version = strstr(version, "HTTP/1.1")) != NULL){
        version[tmp_version - version + strlen("HTTP/1.1") - 1] = '0';
    }
}

void read_requesthdrs(rio_t *rp, char *other_hdr) {
    char buf[MAXLINE];

    while(Rio_readlineb(rp, buf, MAXLINE) > 0) {
        if (!strcmp(buf, "\r\n"))
            break;
        
        if (strncasecmp(buf, "Connection", 10) != 0 
            && strncasecmp(buf, "Host", 4) != 0
            && strncasecmp(buf, "Proxy-Connection", 16) != 0
            && strncasecmp(buf, "User-Agent", 10)) {
            strcat(other_hdr, buf);
        }
    }
}

// void clienterror(int fd, char *cause, char *errnum, 
// 		 char *shortmsg, char *longmsg) 
// {
//     char buf[MAXLINE], body[MAXBUF];

//     /* Build the HTTP response body */
//     sprintf(body, "<html><title>Tiny Error</title>");
//     sprintf(body, "%s<body bgcolor=""ffffff"">\r\n", body);
//     sprintf(body, "%s%s: %s\r\n", body, errnum, shortmsg);
//     sprintf(body, "%s<p>%s: %s\r\n", body, longmsg, cause);
//     sprintf(body, "%s<hr><em>The Tiny Web server</em>\r\n", body);

//     /* Print the HTTP response */
//     sprintf(buf, "HTTP/1.0 %s %s\r\n", errnum, shortmsg);
//     rio_writen(fd, buf, strlen(buf));
//     sprintf(buf, "Content-type: text/html\r\n");
//     rio_writen(fd, buf, strlen(buf));
//     sprintf(buf, "Content-length: %d\r\n\r\n", (int)strlen(body));
//     rio_writen(fd, buf, strlen(buf));
//     rio_writen(fd, body, strlen(body));
// }

void *thread(void *vargp) {
    int connfd = *((int *)vargp);
    Pthread_detach(pthread_self());
    Free(vargp);
    doit(connfd);
    Close(connfd);
    return NULL;
}

int main(int argc, char **argv) 
{
    Signal(SIGPIPE, SIG_IGN);
    int listenfd, *connfd;
    char hostname[MAXLINE], port[MAXLINE];
    socklen_t clientlen;
    struct sockaddr_storage clientaddr;//sockaddr_in
    pthread_t tid;
    /* Check command line args */
    if (argc != 2) {
        fprintf(stderr, "usage: %s <port>\n", argv[0]);
        exit(1);
    }
    cache_init(&cache);

    listenfd = open_listenfd(argv[1]);

    while(1) {
        clientlen = sizeof(clientaddr);
        // 防止竞争
        connfd = Malloc(sizeof(int));
        *connfd = Accept(listenfd, (SA*)&clientaddr, &clientlen);
        getnameinfo((SA *) &clientaddr, clientlen, hostname, MAXLINE, 
                        port, MAXLINE, 0);
        printf("Accepted connection from (%s, %s)\n", hostname, port);
        Pthread_create(&tid, NULL, thread, connfd);
    }
}